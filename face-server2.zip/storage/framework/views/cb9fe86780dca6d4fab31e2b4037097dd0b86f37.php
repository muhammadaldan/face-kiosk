<table id="data_table" class="display">
        <thead>
            <tr>
                <th style="border:1px solid black">#</th>            
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $abcent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="border:1px solid black"><?php echo e($key+1); ?></td>                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table><?php /**PATH C:\laragon\www\face-server2\resources\views/report/abcent.blade.php ENDPATH**/ ?>