module.exports = {
    important: true,
    future: {
        // removeDeprecatedGapUtilities: true,
        // purgeLayersByDefault: true,
    },
    purge: [],
    theme: {
        extend: {}
    },
    variants: {},
    plugins: []
};
