<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Abcent;
use App\Exports\AbcentExport;
use Maatwebsite\Excel\Facades\Excel;

class ReportController extends Controller
{
    public function excel(Request $request)
    {
        return Excel::download(new AbcentExport($request->date), 'report abcent '.now().'.xlsx');
    }
}
