<?php

namespace App\Exports;

use App\Models\Abcent;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class AbcentExport implements FromView, ShouldAutoSize
{    
    protected $date;

    public function __construct($date) 
    {
        $this->date = $date;
    }

    public function view(): View
    {
        $firstDate = '';
        $secondDate = '';
        if (count($this->date) === 1) {
            Abcent::whereDate('arrival', $this->date)->get();
        }
        return view('report.abcent', [
            'abcent' => Abcent::all()
        ]);
    }
}
