<template>
    <v-card class="p-8">
        <v-row>
            <v-col cols="12" sm="4">
                <v-date-picker
                    v-model="dates"
                    range
                    color="blue"
                ></v-date-picker>
            </v-col>
            <v-col cols="12" sm="6">
                <v-text-field
                    v-model="dateRangeText"
                    label="Date range"
                    prepend-icon="mdi-calendar"
                    readonly
                ></v-text-field>
                <v-btn
                    color="success"
                    elevation="0"
                    @click="printExcel"
                    :loading="loading1"
                    >Excel</v-btn
                >
                <v-btn color="warning" elevation="0">PDF</v-btn>
            </v-col>
        </v-row>
    </v-card>
</template>

<script>
export default {
    data() {
        return {
            dates: [new Date().toISOString().substr(0, 10)],
            loading1: false
        };
    },
    computed: {
        dateRangeText() {
            return this.dates.join(" ~ ");
        }
    },
    methods: {
        printExcel() {
            const vm = this;
            vm.loading1 = true;
            axios
                .post(`/report/excel`, { date: vm.dates })
                .then(response => {
                    if (response.data.status) {
                        vm.alert = true;
                        vm.messages = "success";
                        vm.alertColor = "success";
                        setting.name = response.data.data.name;
                        setting.logo = response.data.data.logo;
                    } else {
                        vm.alert = true;
                        vm.messages = response.data.message[0];
                        vm.alertColor = "danger";
                    }

                    vm.loading1 = false;
                })
                .catch(error => {
                    vm.loading1 = false;
                    console.log(error);
                    alert(error);
                });
        }
    }
};
</script>
