<table id="data_table" class="display">
        <thead>
            <tr>
                <th style="border:1px solid black">#</th>            
            </tr>
        </thead>
        <tbody>
            @foreach ($abcent as $key => $value)
                <tr>
                    <td style="border:1px solid black">{{ $key+1 }}</td>                    
                </tr>
            @endforeach
        </tbody>
    </table>