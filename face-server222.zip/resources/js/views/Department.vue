<template>
    <div>
        <v-table></v-table>
    </div>
</template>

<script>
import VTable from '../components/department/Table.vue'

export default {
    components:{
        VTable
    }
}
</script>