<template>
    <div><v-table></v-table></div>
</template>

<script>
import VTable from "../components/user/Table.vue";

export default {
    components: {
        VTable
    }
};
</script>
