<template>
    <div>
        <v-table></v-table>
    </div>
</template>

<script>
import VTable from '../components/employee/Table.vue'

export default {
    components:{
        VTable
    }
}
</script>