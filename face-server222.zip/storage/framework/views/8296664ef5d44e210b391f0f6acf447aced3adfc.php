<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h3>Report : <?php echo e($date[0]); ?> ~ <?php echo e($date[1]); ?></h3>
    <table id="data_table" style="margin-left:100px">          
        <tbody>
            <tr>
                <td rowspan="2" style="text-align:center;border:1px solid black">#</td>            
                <td rowspan="2" style="text-align:center;border:1px solid black">ID</td>            
                <td rowspan="2" style="text-align:center;border:1px solid black">Name</td>                            
                <td colspan="2" style="text-align:center;border:1px solid black"><?php echo e($date[0]); ?></td>     
            </tr>        
            <tr>
                <td  style="text-align:center;border:1px solid black">Arrival</td>
                <td  style="text-align:center;border:1px solid black">Time home</td>       
            </tr>            
            <?php $__currentLoopData = $abcent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="border:1px solid black"><?php echo e($key+1); ?></td>                    
                    <td style="border:1px solid black;text-align:left"><?php echo e($value->nim); ?></td>                    
                    <td style="border:1px solid black"><?php echo e($value->name); ?></td>

                <?php if(count($value->abcent) > 0): ?>                        
                    <?php $__currentLoopData = $value->abcent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $abcent2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $arrival = new DateTime($abcent2->arrival);
                            $waktu_pulang = new DateTime($abcent2->waktu_pulang);
                            $dates = $date[0]; //
                        ?>

                        <?php if($date[1] !== ''): ?>                        
                            <?php if($arrival->format('Y-m-d') == $dates): ?>
                            <td style="text-align:center;border:1px solid black"><?php echo e($abcent2->arrival ?? '-'); ?></td>
                                <td style="text-align:center;border:1px solid black"><?php echo e($abcent2->waktu_pulang ?? '-'); ?></td>
                                <?php else: ?>
                                <td style="text-align:center;border:1px solid black">-</td>
                                <?php endif; ?>
                        <?php else: ?>
                            <td style="text-align:center;border:1px solid black"><?php echo e($abcent2->arrival ?? '-'); ?></td>
                            <td style="text-align:center;border:1px solid black"><?php echo e($abcent2->waktu_pulang ?? '-'); ?></td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <?php                            
                            $dates = $date[0]; //
                        ?>
                        <?php if($date[1] !== ''): ?>                        
                            <td style="text-align:center;border:1px solid black">-</td>                             
                            <td style="text-align:center;border:1px solid black">-</td>                             
                        <?php else: ?>
                            <td style="text-align:center;border:1px solid black">-</td>                             
                            <td style="text-align:center;border:1px solid black">-</td>   
                        <?php endif; ?>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
         <?php            
            $dates = $date[0]; //
        ?>
         <?php if($date[1] !== ''): ?>                        
            <?php while($dates < $date[1]): ?>                                                                
             <?php            
                $dates++
            ?>
            <tbody>
                <tr>
                    <td rowspan="2" style="text-align:center;border:1px solid black">#</td>            
                    <td rowspan="2" style="text-align:center;border:1px solid black">ID</td>            
                    <td rowspan="2" style="text-align:center;border:1px solid black">Name</td>                            
                    <td colspan="2" style="text-align:center;border:1px solid black"><?php echo e($dates); ?></td>     
                </tr>        
                <tr>
                    <td  style="text-align:center;border:1px solid black">Arrival</td>
                    <td  style="text-align:center;border:1px solid black">Time home</td>       
                </tr>            
                <?php $__currentLoopData = $abcent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                                                
                        
                        <td style="border:1px solid black"><?php echo e($key+1); ?></td>                    
                        <td style="border:1px solid black;text-align:left"><?php echo e($values->nim); ?></td>                    
                        <td style="border:1px solid black"><?php echo e($values->name); ?></td>
                        

                        <?php if(count($value->abcent) > 0): ?>                        
                            <?php $__currentLoopData = $values->abcent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $abcent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                                <td style="text-align:center;border:1px solid black"><?php echo e($abcent->arrival ?? '-'); ?></td>
                                <td style="text-align:center;border:1px solid black"><?php echo e($abcent->waktu_pulang ?? '-'); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>                                                
                                <td style="text-align:center;border:1px solid black">-</td>                             
                                <td style="text-align:center;border:1px solid black">-</td>                           
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
               
            <?php endwhile; ?>
        <?php endif; ?>
    </table>
</body>
</html><?php /**PATH C:\laragon\www\face-server2\resources\views/report/pdf.blade.php ENDPATH**/ ?>