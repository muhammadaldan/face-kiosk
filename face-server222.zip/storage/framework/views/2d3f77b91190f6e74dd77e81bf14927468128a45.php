<table id="data_table" class="display">
        <tbody>
            <tr>
                <td rowspan="2" style="text-align:center;border:1px solid black">#</td>            
                <td rowspan="2" style="text-align:center;border:1px solid black">ID</td>            
                <td rowspan="2" style="text-align:center;border:1px solid black">Name</td>                            
                <td colspan="2" style="text-align:center;border:1px solid black"><?php echo e($date[0]); ?></td>     
                <?php
                    $dates = $date[0]; //
                    ?>
                <?php if($date[1] !== ''): ?>                
                    <?php while($dates < $date[1]): ?>                                    
                        <td colspan="2" style="text-align:center;border:1px solid black"><?php echo e($dates++); ?></td>
                    <?php endwhile; ?>
                <?php endif; ?>          
            </tr>        
            <tr>
                <td  style="text-align:center;border:1px solid black">Arrival</td>
                <td  style="text-align:center;border:1px solid black">Time home</td>       
                <?php
                $dates = $date[0]; //
                ?>

                <?php if($date[1] !== ''): ?>                
                    <?php while($dates < $date[1]): ?>                                    
                        <td  style="text-align:center;border:1px solid black">Arrival</td>
                        <td  style="text-align:center;border:1px solid black">Time home</td>      
                    <?php
                        $dates++;
                    ?>
                    <?php endwhile; ?>
                <?php endif; ?>              
            </tr>            
            <?php $__currentLoopData = $abcent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="border:1px solid black"><?php echo e($key+1); ?></td>                    
                    <td style="border:1px solid black;text-align:left"><?php echo e($value->nim); ?></td>                    
                    <td style="border:1px solid black"><?php echo e($value->name); ?></td>

                
                    
                    <?php if(count($value->abcent) > 0): ?>                        
                    <?php $__currentLoopData = $value->abcent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $abcent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $arrival = new DateTime($abcent->arrival);
                            $waktu_pulang = new DateTime($abcent->waktu_pulang);
                            $dates = $date[0]; //
                        ?>

                        <?php if($date[1] !== ''): ?>                        
                            <?php while($dates < $date[1]): ?>                                                                
                            <?php if($arrival->format('Y-m-d') == $dates): ?>
                            <td style="text-align:center;border:1px solid black"><?php echo e($abcent->arrival ?? '-'); ?></td>
                                <td style="text-align:center;border:1px solid black"><?php echo e($abcent->waktu_pulang ?? '-'); ?></td>
                                <?php else: ?>
                                <td style="text-align:center;border:1px solid black">-</td>
                                <?php endif; ?>
                                
                                
                                <?php
                                    $dates++;
                                    ?>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <td style="text-align:center;border:1px solid black"><?php echo e($abcent->arrival ?? '-'); ?></td>
                            <td style="text-align:center;border:1px solid black"><?php echo e($abcent->waktu_pulang ?? '-'); ?></td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <?php                            
                            $dates = $date[0]; //
                        ?>
                        <?php if($date[1] !== ''): ?>                        
                        <?php while($dates < $date[1]): ?>                           
                            <td style="text-align:center;border:1px solid black">-</td>                             
                            <td style="text-align:center;border:1px solid black">-</td>                             
                            <?php
                                $dates++;
                            ?>
                        <?php endwhile; ?>
                        <?php else: ?>
                            <td style="text-align:center;border:1px solid black">-</td>                             
                            <td style="text-align:center;border:1px solid black">-</td>   
                        <?php endif; ?>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table><?php /**PATH C:\laragon\www\face-server2\resources\views/report/excel.blade.php ENDPATH**/ ?>